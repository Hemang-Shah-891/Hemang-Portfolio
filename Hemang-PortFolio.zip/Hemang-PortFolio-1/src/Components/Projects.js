// export default function Project() {
//   return (
//     <div
//       className="h-[1700px] pt-16 scroll-mt-24 flex flex-col items-center px-4 md:px-10 "
//       id="projects"
//     >
//       <h1 className="text-center text-3xl font-bold ">PROJECTS</h1>
//       <p className="text-center mt-6 text-gray-900 text-lg md:text-xl">
//         Here you will find some of the personal projects that I created with
//         each project <br></br>
//         containing its own case study
//       </p>
//       <div className="flex flex-wrap gap-20 mt-20 ">
//         <div className="border-2 rounded-2xl  h-96 lg:w-[700px] md:w-[900px] sm:w-[1100px]  p-5">
//           <img
//             src={require("./project-1.png")}
//             alt="logo"
//             className="h-full w-full"
//           />
//         </div>
//         <div className="border-2- h-96 lg:w-[500px] md:w-[700px] sm:w-[900px] p-5">
//           <h1 className="text-3xl font-bold mt-10">React Quiz App</h1>
//           <p className="mt-8 text-lg text-gray-700">
//             Created a Quiz App which tests React Fundamentals. <br></br>
//             App randomly showns questions out of 15 questions.<br></br>
//             ReactJS features used :
//             <span className="font-medium">
//               use-Reducer hooks and Advanced React Router.{" "}
//             </span>
//           </p>
//           <a
//             href="https://react-quized.netlify.app/"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             <button
//               className="relative mt-8 h-[8vh] w-[20vh] rounded-l-full rounded-br-full
//                bg-gradient-to-r from-blue-500 via-purple-800 to-pink-500
//                text-white font-extrabold transition-all duration-300 overflow-hidden
//                before:absolute before:top-0 before:left-0 before:w-0 before:h-full
//                before:bg-purple-800 before:transition-all before:duration-500 before:ease-in-out
//                hover:before:w-full hover:text-white z-10"
//             >
//               <span className="relative z-20">LIVE LINK</span>
//             </button>
//           </a>
//         </div>
//       </div>

//       <div className="flex flex-wrap gap-20 mt-20 ">
//         <div className="border-2 rounded-2xl  h-96 lg:w-[700px] md:w-[900px] sm:w-[1100px]  object-cover p-5">
//           <img
//             src={require("./project-3.png")}
//             alt="logo"
//             className="h-full w-full "
//           />
//         </div>
//         <div className="border-2- h-96 lg:w-[500px] md:w-[700px] sm:w-[900px] p-5">
//           <h1 className="text-3xl font-bold mt-10">Food Delivery App</h1>
//           <p className="mt-8 text-lg text-gray-700">
//             Created a Food Delivery Restaurant which is static website <br></br>
//             App normally has How-it-works Section, Meals Section and
//             Testimonials Section<br></br>
//             Features used :
//             <span className="font-medium">
//               HTML5, CSS3 and Responsive Design
//             </span>
//           </p>
//           <a
//             href="https://omnifood-hemangshah.netlify.app/"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             <button
//               className="relative mt-8 h-[8vh] w-[20vh] rounded-l-full rounded-br-full
//                bg-gradient-to-r from-blue-500 via-purple-800 to-pink-500
//                text-white font-extrabold transition-all duration-300 overflow-hidden
//                before:absolute before:top-0 before:left-0 before:w-0 before:h-full
//                before:bg-purple-800 before:transition-all before:duration-500 before:ease-in-out
//                hover:before:w-full hover:text-white z-10"
//             >
//               <span className="relative z-20">LIVE LINK</span>
//             </button>
//           </a>
//         </div>
//       </div>

//       <div className="flex flex-wrap gap-20 mt-20 ">
//         <div className="border-2 rounded-2xl  h-96 lg:w-[700px] md:w-[900px] sm:w-[1100px]  p-5">
//           <img
//             src={require("./project-4.png")}
//             alt="logo"
//             className="h-full w-full"
//           />
//         </div>
//         <div className="border-2- h-96 lg:w-[500px] md:w-[700px] sm:w-[900px] p-5">
//           <h1 className="text-3xl font-bold mt-10">Pig Game</h1>
//           <p className="mt-8 text-lg text-gray-700">
//             Created a Game with JavaScript Features. <br></br>
//             It's mostly Dynamic and switching to each side<br></br>
//             ReactJS features used :
//             <span className="font-medium">
//               Dom Manipulation, Event Listeners, Random Number Generation, State
//               Management
//             </span>
//           </p>
//           <a
//             href="https://pig-gamezz.netlify.app/"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             <button
//               className="relative mt-8 h-[8vh] w-[20vh] rounded-l-full rounded-br-full
//                bg-gradient-to-r from-blue-500 via-purple-800 to-pink-500
//                text-white font-extrabold transition-all duration-300 overflow-hidden
//                before:absolute before:top-0 before:left-0 before:w-0 before:h-full
//                before:bg-purple-800 before:transition-all before:duration-500 before:ease-in-out
//                hover:before:w-full hover:text-white z-10"
//             >
//               <span className="relative z-20">LIVE LINK</span>
//             </button>
//           </a>
//         </div>
//       </div>
//     </div>
//   );
// }

export default function Project() {
  return (
    <section
      className="min-h-[1600px] pt-16 pb-16 scroll-mt-24 flex flex-col items-center px-4 md:px-10"
      id="projects"
    >
      <h1 className="text-center text-3xl font-bold">PROJECTS</h1>
      <p className="text-center mt-6 text-gray-900 text-lg md:text-xl">
        Here you will find some of the personal projects that I created, each
        containing its own case study.
      </p>

      {[
        {
          title: "React Quiz App",
          description:
            "Created a Quiz App which tests React Fundamentals. App randomly shows questions out of 15 questions. ReactJS features used: useReducer hook and Advanced React Router.",
          link: "https://react-quized.netlify.app/",
          image: require("./project-1.png"),
        },
        {
          title: "Food Delivery App",
          description:
            "Created a Food Delivery Restaurant which is a static website. App includes How-it-works, Meals, and Testimonials sections. Features used: HTML5, CSS3, and Responsive Design.",
          link: "https://omnifood-hemangshah.netlify.app/",
          image: require("./project-3.jpg"),
        },
        {
          title: "Pest Control Website",
          description:
            "Created a Pest Control Website which is a static website. Website includes the details of Sai Suchith Pest Control. Features used: Animation and Tailwind CSS",
          link: "https://sspcin.netlify.app/",
          image: require("./project-2.png"),
        },
        {
          title: "Pig Game",
          description:
            "Created a Game with JavaScript Features. It's dynamic and switches between players. Features used: DOM Manipulation, Event Listeners, Random Number Generation, and State Management.",
          link: "https://pig-gamezz.netlify.app/",
          image: require("./project-4.png"),
        },
      ].map((project, index) => (
        <div
          key={index}
          className="flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-10 mt-16 md:mt-20 w-full max-w-6xl"
        >
          <div className="border-2 rounded-2xl h-96 lg:h-[400px] w-full md:w-1/2 p-3 md:p-5 overflow-hidden">
            <img
              src={project.image}
              alt="project"
              className="h-full w-full object-cover object-center rounded-2xl"
            />
          </div>
          <div className="h-96 lg:h-[400px] w-full md:w-1/2 p-3 md:p-5 flex flex-col justify-center">
            <h1 className="text-3xl font-bold mt-2 md:mt-10">
              {project.title}
            </h1>
            <p className="mt-2 md:mt-8 text-lg text-gray-700">
              {project.description}
            </p>
            <a href={project.link} target="_blank" rel="noopener noreferrer">
              <button className="relative mt-4 md:mt-8 h-[8vh] w-[20vh] rounded-l-full rounded-br-full bg-gradient-to-r from-blue-500 via-purple-800 to-pink-500 text-white font-extrabold transition-all duration-300 overflow-hidden before:absolute before:top-0 before:left-0 before:w-0 before:h-full before:bg-purple-800 before:transition-all before:duration-500 before:ease-in-out hover:before:w-full hover:text-white z-10">
                <span className="relative z-20">LIVE LINK</span>
              </button>
            </a>
          </div>
        </div>
      ))}
    </section>
  );
}
