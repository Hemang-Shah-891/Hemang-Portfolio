export default function Contact() {
  return (
    <div
      className="w-full h-[580px] md:h-[400px] bg-gradient-to-r from-[#f9a8d4] to-[#c084fc] pt-14 scroll-mt-24"
      id="contact"
    >
      <div
        className="border-2 max-w-6xl mx-auto pt-16 p-8 scroll-mt-44 shadow-2xl rounded-lg bg-white"
        id="contact"
      >
        {/* Title */}
        <h1 className="text-3xl font-bold text-center">CONTACT</h1>

        {/* Name, Email & Phone Fields */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          <div className="flex flex-col">
            <label className="text-lg font-medium">Name:</label>
            <div className="border-2- w-full h-12 p-3 mt-2 rounded-md">
              Hemang Shah
            </div>
          </div>
          <div className="flex flex-col">
            <label className="text-lg font-medium">Email:</label>
            <div className="border-2- w-full h-12 p-3 mt-2 rounded-md">
              hemangshah891@gmail.com
            </div>
          </div>
          <div className="flex flex-col">
            <label className="text-lg font-medium">Phone No. :</label>
            <div className="border-2- w-full h-12 p-3 mt-2 rounded-md">
              +91 9284636747
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
