// export default function Home() {
//   return (
//     <div>
//       <div className="h-[730px] bg-gradient-to-r from-[#3b82f6] via-[#6b21a8]- to-[#ec4899] pt-32 flex pt-72 justify-center">
//         <h1 className="text-white drop-shadow-lg text-6xl ">
//           HEY, I'M HEMANG SHAH
//         </h1>
//       </div>

//       <p className="text-white pt-32">
//         A Result-Oriented Web Developer building and managing Websites and Web
//         <br></br>
//         Applications that leads to the success of the overall product
//       </p>
//     </div>
//   );
// }

export default function Home() {
  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    // Close menu on mobile after clicking
  };

  return (
    <div className="text-white" id="home">
      {/* Hero Section */}
      <div className="min-h-screen bg-gradient-to-r from-[#3b82f6] to-[#ec4899] flex flex-col items-center justify-center text-center px-6">
        <h1 className="drop-shadow-lg text-6xl font-bold mt-12">
          HEY, I'M HEMANG SHAH
        </h1>
        <p className="mt-8 text-xl max-w-3xl">
          A Result-Oriented Frontend Developer building and managing Websites
          and Web Applications that lead to the success of the overall product.
        </p>
        <a
          href="https://drive.google.com/file/d/1Yi-6qk5ydbhpqLKoLiIgPbhFjoGfJD5s/view?usp=drivesdk"
          target="_blank"
          rel="noopener noreferrer"
        >
          <button
            className="relative mt-10 h-[10vh] w-[25vh] rounded-l-full rounded-br-full px-6 py-3 
          bg-gradient-to-r from-[#3b82f6] via-[#6b21a8] to-[#ec4899]  text-white font-extrabold 
           overflow-hidden transition-all duration-300 
           before:content-[''] before:absolute before:top-0 before:left-0 
           before:w-0 before:h-full before:bg-[#6b21a8] before:transition-all 
           before:duration-500 before:ease-in-out 
           hover:before:w-full hover:text-white"
            // id="projects"
          >
            <span
              className="relative z-10 "
              onClick={() => scrollToSection("projects")}
            >
              RESUME
            </span>
          </button>
        </a>
      </div>
    </div>
  );
}
