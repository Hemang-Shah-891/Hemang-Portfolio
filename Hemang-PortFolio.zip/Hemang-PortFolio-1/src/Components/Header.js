// import HemangImage from "./Hemang.jpg";

// const Header = () => {
//   const scrollToSection = (id) => {
//     document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
//   };

//   return (
//     <div className="bg-gradient-to-r from-[#3b82f6] to-[#ec4899] bg-opacity-50- h-[15vh] w-full flex items-center justify-between px-14 fixed top-0">
//       {/* Logo and Name */}
//       <div className="flex items-center gap-5 text-2xl">
//         <img
//           src={HemangImage}
//           alt="Hemang Shah"
//           className="h-[10vh] w-[10vh] border-2 rounded-full border-zinc-200"
//         />
//         <h2 className="text-white font-semibold">HEMANG SHAH</h2>
//       </div>

//       {/* Navigation Menu */}
//       <ol className="flex gap-16 text-white text-2xl cursor-pointer">
//         <li
//           className="hover:text-gray-300 transition duration-200"
//           onClick={() => scrollToSection("home")}
//         >
//           HOME
//         </li>
//         <li
//           className="hover:text-gray-300 transition duration-200"
//           onClick={() => scrollToSection("about")}
//         >
//           ABOUT ME
//         </li>
//         <li className="hover:text-gray-300 transition duration-200">
//           PROJECTS
//         </li>
//         <li
//           className="hover:text-gray-300 transition duration-200"
//           onClick={() => scrollToSection("contact")}
//         >
//           CONTACT
//         </li>
//       </ol>
//     </div>
//   );
// };

// export default Header;

import { useState } from "react";
import HemangImage from "./Hemang.jpg";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setIsOpen(false); // Close menu on mobile after clicking
  };

  return (
    <header className="bg-gradient-to-r from-[#3b82f6] to-[#ec4899] bg-opacity-90 fixed top-0 w-full h-[12vh] md:h-[15vh] flex items-center justify-between px-6 md:px-14 z-50">
      {/* Logo and Name */}
      <div className="flex items-center gap-3 md:gap-5 text-lg md:text-2xl">
        <img
          src={HemangImage}
          alt="Hemang Shah"
          className="h-[8vh] w-[8vh] md:h-[10vh] md:w-[10vh] border-2 rounded-full border-zinc-200"
        />
        <h2 className="text-white font-semibold">HEMANG SHAH</h2>
      </div>

      {/* Desktop Navigation */}
      <nav className="hidden md:flex gap-10 lg:gap-16 text-white text-lg md:text-2xl">
        {["home", "about", "projects", "contact"].map((section) => (
          <span
            key={section}
            className="hover:text-gray-300  transition duration-200 cursor-pointer"
            onClick={() => scrollToSection(section)}
          >
            {section.toUpperCase()}
          </span>
        ))}
      </nav>

      {/* Mobile Menu Toggle */}
      <button
        className="md:hidden text-white"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          // Close Icon
          <svg
            className="w-8 h-8"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M6.225 4.811a1 1 0 011.414 0L12 9.172l4.361-4.361a1 1 0 011.414 1.414L13.414 10.586l4.361 4.361a1 1 0 11-1.414 1.414L12 12l-4.361 4.361a1 1 0 01-1.414-1.414l4.361-4.361-4.361-4.361a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        ) : (
          // Hamburger Icon
          <svg
            className="w-8 h-8"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M3 6a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 6a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 6a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1z"
              clipRule="evenodd"
            />
          </svg>
        )}
      </button>

      {/* Mobile Navigation Menu */}
      {isOpen && (
        <div className="absolute top-[12vh] right-0 w-full bg-gradient-to-r from-[#3b82f6] to-[#ec4899] md:hidden flex flex-col items-center gap-6 text-white text-xl py-6 shadow-lg">
          {["home", "about", "projects", "contact"].map((section) => (
            <span
              key={section}
              className="hover:text-gray-300 transition duration-200 cursor-pointer"
              onClick={() => scrollToSection(section)}
            >
              {section.toUpperCase()}
            </span>
          ))}
        </div>
      )}
    </header>
  );
};

export default Header;
