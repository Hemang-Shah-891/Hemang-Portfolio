// export default function About() {
//   return (
//     <div
//       className="h-[650px] bg-gradient-to-r from-[#60a5fa] to-[#f472b6]  pt-10 scroll-mt-24"
//       id="about"
//     >
//       <h1 className="text-3xl font-bold text-center">ABOUT ME</h1>
//       <p className="mt-8 text-white text-center text-xl max-w-3xl-">
//         Here you will find more information about me, what I do, and my current
//         skills mostly in terms<br></br>
//         of programming and technology
//       </p>

//       <div className="flex items-center justify-center gap-20 mt-24">
//         <div>
//           <h6 className="text-3xl font-bold">Get to Know me!</h6>
//           <p className="mt-12 text-white text-xl max-w-3xl">
//             I'm a Frontend Developer building and managing<br></br>
//             Websites and Web Applications. In my current role at <br></br>
//             Shri Hari Info Solutions with Experience of 1 year Internship,{" "}
//             <br></br>I honed my skills in specific technologies.
//           </p>

//           <p className="mt-8 text-white text-xl max-w-3xl">
//             I'm open to job opportunities where I can contribute, learn{" "}
//             <br></br>
//             and grow. If you have a good opportunity that matches my <br></br>
//             skills and experience then please feel free to contact me
//           </p>
//         </div>

//         <div>
//           <h6 className="text-3xl text-left font-bold mt-[-70px]">My Skills</h6>
//           <div className="grid grid-cols-4 gap-5- mt-7">
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[80px] mt-8 text-zinc-600 mb-5 cursor-none">
//               HTML
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[80px] mt-8 text-zinc-600 mb-5 cursor-none">
//               CSS
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[140px] mt-8 text-zinc-600 mb-5 mr-7 cursor-none">
//               TAILWIND CSS
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[120px] mt-8 text-zinc-600 mb-5 cursor-none">
//               JAVASCRIPT
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[100px] mt-8 text-zinc-600 mb-5 cursor-none">
//               REACT
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[100px] mt-8 text-zinc-600 mb-5 cursor-none">
//               REDUX
//             </button>
//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[80px] mt-8 text-zinc-600 mb-5 cursor-none">
//               JAVA
//             </button>

//             <button className="border bg-gray-300 rounded-3xl p-1 h-[40px] w-[80px] mt-8 text-zinc-600 mb-5 cursor-none">
//               GITHUB
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

export default function About() {
  return (
    <section
      className="min-h-[650px] pt-16 scroll-mt-24 flex flex-col items-center px-4 md:px-10 bg-gray-100 bg-[url('https://www.rammaheshwari.com/assets/svg/common-bg.svg')]- bg-cover bg-center"
      id="about"
    >
      {/* Title */}
      <h1 className="text-3xl md:text-4xl font-bold text-black text-center">
        ABOUT ME
      </h1>

      {/* Description */}
      <p className="mt-6 text-gray-900 text-lg md:text-xl text-center max-w-3xl">
        Here you will find more information about me, what I do, and my current
        skills mostly in terms of programming and technology.
      </p>

      {/* Main Content */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-12 mt-12 w-full max-w-6xl">
        {/* Get to Know Me Section */}
        <div className="w-full md:w-1/2 text-center md:text-left space-y-6">
          <h6 className="text-2xl md:text-xl font-bold text-black">
            Get to Know Me!
          </h6>
          <p className="text-gray-900 text-lg leading-relaxed">
            I'm a Frontend Developer building and managing Websites and Web
            Applications. In my current role at
            <span className="font-semibold"> Shri Hari Info Solutions</span>,
            with 1 year of internship experience, I honed my skills in various
            technologies.
          </p>
          <p className="text-gray-900 text-lg leading-relaxed">
            I'm open to job opportunities where I can contribute, learn, and
            grow. If you have a great opportunity that matches my skills and
            experience, feel free to contact me!
          </p>
        </div>

        {/* My Skills Section */}
        <div className="w-full md:w-1/2 flex flex-col items-center md:items-start">
          <h6 className="text-2xl md:text-xl font-bold text-black text-center md:text-left">
            My Skills
          </h6>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-6 w-full">
            {[
              "HTML",
              "CSS",
              "TAILWIND CSS",
              "JAVASCRIPT",
              "REACT",
              "REDUX",
              "JAVA",
              "GITHUB",
            ].map((skill, index) => (
              <span
                key={index}
                className="border bg-gray-300 text-zinc-600 rounded-3xl py-2 px-4 text-sm sm:text-base font-semibold text-center cursor-default min-w-[100px] h-[40px] flex items-center justify-center"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
