import { FaGithub } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa6";

export default function footer() {
  return (
    <footer className="bg-gray-900 text-white mt-20- py-16 px-6 md:px-20 text-center">
      <div className="flex flex-col md:flex-row justify-between items-center max-w-6xl mx-auto">
        <div>
          <h2 className="text-2xl font-bold">Hemang Shah</h2>
          <p className="text-gray-400 mt-3">Frontend Developer</p>
        </div>

        <div className="flex flex-col items-center mt-4 md:mt-0">
          <p className=" mb-2 text-2xl font-bold">Social</p>
          <div className="flex gap-6 mt-5">
            <a
              href="https://github.com/Hemang-Shah-891"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaGithub className="w-10 h-10" />
            </a>
            <a
              href="https://www.linkedin.com/in/hemangshah369/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaLinkedin className="w-10 h-10" />
            </a>
          </div>
        </div>
      </div>
      <p className="mt-6 text-gray-500">
        &copy; Copyright {new Date().getFullYear()}. Made by
        <span className="font-bold text-white"> Hemang Shah</span>
      </p>
    </footer>
  );
}
